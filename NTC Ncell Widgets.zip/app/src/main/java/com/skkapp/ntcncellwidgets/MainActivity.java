package com.skkapp.ntcncellwidgets;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;
import android.Manifest;
import android.content.pm.PackageManager;


public class MainActivity extends  Activity { 
	
	
	private View FloatingWindow;
	private WindowManager window1_windowManager;
	private WindowManager.LayoutParams window1_layoutParams;
	private View window1_displayView;
	private boolean window1_b = true;
	private Intent intent1 = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.CALL_PHONE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		window1_windowManager = (WindowManager) getSystemService(WINDOW_SERVICE); 
		window1_layoutParams = new WindowManager.LayoutParams();
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			window1_layoutParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
				} else {
						window1_layoutParams.type = WindowManager.LayoutParams.TYPE_PHONE;
		}
				window1_layoutParams.format = PixelFormat.RGBA_8888;
				window1_layoutParams.gravity = Gravity.LEFT | Gravity.TOP;
		
				window1_layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
	}
	
	private void initializeLogic() {
		if (android.provider.Settings.canDrawOverlays(MainActivity.this)) {
			window1_layoutParams.width = 250;
			window1_layoutParams.height = 400;
			window1_layoutParams.x = 0;
			window1_layoutParams.y = 0;
			window1_show();
			finishAffinity();
		}
		else {
			finishAffinity();
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	//FloatingWindow
	private void window1_showFloatingWindow() {
		LayoutInflater window1_layoutInflater = LayoutInflater.from(getApplicationContext());
		window1_displayView = window1_layoutInflater.inflate(R.layout.window1, null);
		
		window1_displayView.setOnTouchListener(new window1FloatingOnTouchListener());
		
		final LinearLayout linear1 =  window1_displayView.findViewById(R.id.linear1);
					final LinearLayout linear2 =  window1_displayView.findViewById(R.id.linear2);
					final LinearLayout linear3 = window1_displayView.findViewById(R.id.linear3);
					final ImageView imageview1 =  window1_displayView.findViewById(R.id.imageview1);
					final RadioGroup radiogroup1 =  window1_displayView.findViewById(R.id.radiogroup1);
					final Button button1 =  window1_displayView.findViewById(R.id.button1);
					final Button button2 =  window1_displayView.findViewById(R.id.button2);
					final Button button3 =  window1_displayView.findViewById(R.id.button3);
					final Button button4 =  window1_displayView.findViewById(R.id.button4);
					final RadioButton radiobutton1 =  window1_displayView.findViewById(R.id.radiobutton1);
					final RadioButton radiobutton2 =  window1_displayView.findViewById(R.id.radiobutton2);
					
		linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFFFFFFF));
		linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF3F51B5));
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				window1_closes();
			}
		});
		intent1.setAction(Intent.ACTION_CALL);
		linear3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (radiobutton1.isChecked()) {
					intent1.setData(Uri.parse("tel:*400%23"));
				}
				else {
					intent1.setData(Uri.parse("tel:*901%23"));
				}
				startActivity(intent1);
			}
		});
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (radiobutton1.isChecked()) {
					intent1.setData(Uri.parse("tel:*1415%23"));
				}
				else {
					intent1.setData(Uri.parse("tel:*17123%23"));
				}
				startActivity(intent1);
			}
		});
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (radiobutton1.isChecked()) {
					intent1.setData(Uri.parse("tel:*1415*4%23"));
				}
				else {
					intent1.setData(Uri.parse("tel:*17118%23"));
				}
				startActivity(intent1);
			}
		});
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (radiobutton1.isChecked()) {
					intent1.setData(Uri.parse("tel:*9%23"));
				}
				else {
					intent1.setData(Uri.parse("tel:*903%23"));
				}
				startActivity(intent1);
			}
		});
		
		window1_windowManager.addView(window1_displayView, window1_layoutParams);
		
	}
	
	
	public void window1_closes(){
		
		try{
				
				window1_windowManager.removeView(window1_displayView);
			window1_b = true;
				
		}
		
		catch(Exception e){
				
		}
		
	}
	private void window1_show(){
		
		if (android.provider.Settings.canDrawOverlays(getApplicationContext())) {
			if (window1_b) { window1_showFloatingWindow();
				window1_b = false;
			}
		}
		else {
				Intent intent = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
				Uri.parse("package:" + getPackageName()));
				startActivity(intent);
		}
	}
	
	
	private class window1FloatingOnTouchListener implements View.OnTouchListener {
		
		private int x;
		
		private int y;
		
		
		@Override public boolean onTouch(View view, MotionEvent event) {
				
				
				switch (event.getAction()) {
						
						case MotionEvent.ACTION_DOWN:
						
						x = (int) event.getRawX();
						
						y = (int) event.getRawY();
						
						break;
						
						
						case MotionEvent.ACTION_MOVE:
				 int nowX = (int) event.getRawX();
						
						int nowY = (int) event.getRawY();
						
						int movedX = nowX - x;
						
						int movedY = nowY - y;
						
						x = nowX; y = nowY;
						
						window1_layoutParams.x = window1_layoutParams.x + movedX;
						
						window1_layoutParams.y = window1_layoutParams.y + movedY;
				 window1_windowManager.updateViewLayout(view, window1_layoutParams);
						final int _mX = nowX;
				final int _mY = nowY;
				final int _tX = x;
				final int _tY = y;
				
				
				
				
						break;
						
						default:
						
						break;
						
				}
				
				return true;
				
		}
		
	}
	
	
}
